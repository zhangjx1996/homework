#!/bin/bash
if [ -d "$1" ]; then
cd "$1";
x=`(ls -a)`;
echo "$x" | sed "s/[A-Z]/&&&/g";
else
echo "Not a directory" | cat >> printcap3_error.log
fi
